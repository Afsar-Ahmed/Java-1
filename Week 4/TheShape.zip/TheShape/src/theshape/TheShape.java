/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package theshape;

/**
Afsar Ahmed
* 991432327
Assignment 2
2017-09-29



*/
import java.util.Scanner;

public class TheShape{
    public static void main(String args[]){
	Scanner sc = new Scanner(System.in);
		
	int num; //this variable declares the option
	int base,height; //these variables store the dimensions of a triangle
	int length,width; //these varaibles store the dimensions of a rectangle
        int areaR,areaT; //these variables store the calculated values based on th user's input

	System.out.print("Enter 1 for triangle or any other integer for rectangle: ");
	num=sc.nextInt();
	
	if(num == 1){
           System.out.println("Enter tringle base: ");
           base=sc.nextInt();
           

           if(base<0)
              System.out.println("Base cannot be negative.");
             
           else{
               System.out.println("Enter triangle height: ");
               height=sc.nextInt();
               if(height<0)
                System.out.println("Height cannot be negative.");
               else{
                   areaT=(int).5*height*base;
                   System.out.println(areaT);
               }
           }
			
           

	}

	else{
            System.out.println("Enter rectangle length: ");
            length=sc.nextInt();
            

            if(length<0)
                System.out.println("length cannot be negative.");
            
            else{
                System.out.println("Enter rectangle width: ");
                width=sc.nextInt();
                if(width<0)
		System.out.println("Width cannot be negative.");
                else{
                    areaR=length*width;
                    System.out.println(areaR);
                }
            }
            
			
            


          }
    }
}

	


